﻿const DB_NAME = "material-hub";
const STORE_NAME = "assets";
const DB_VERSION = 1;
const SETTINGS_KEY = "materialHubSettings";
const FOLDERS_KEY = "materialHubFolders";
const DRAG_ASSET_MIME = "application/material-hub-asset-id";

if (!globalThis.chrome) {
  globalThis.chrome = {
    downloads: { download() {} },
    runtime: { onMessage: { addListener() {} }, sendMessage: async () => ({ ok: true }) },
    storage: {
      local: {
        get(keys, callback) {
          callback({});
        },
        set(value, callback) {
          callback?.();
        }
      }
    }
  };
}

const state = {
  assets: [],
  folders: [],
  selected: new Set(),
  objectUrls: new Map(),
  search: "",
  filter: "all",
  folderFilter: "all",
  favoriteOnly: false,
  settings: {
    columns: 2,
    cardSize: 180,
    floatEnabled: true,
    webdav: {
      enabled: false,
      url: "",
      username: "",
      password: "",
      dir: "yun-lou",
      autoSyncMinutes: 0
    }
  }
};

const els = {
  countLabel: document.getElementById("countLabel"),
  clearAll: document.getElementById("clearAll"),
  clearSelected: document.getElementById("clearSelected"),
  deleteMenuToggle: document.getElementById("deleteMenuToggle"),
  deleteMenu: document.getElementById("deleteMenu"),
  downloadMenuToggle: document.getElementById("downloadMenuToggle"),
  downloadMenu: document.getElementById("downloadMenu"),
  downloadAll: document.getElementById("downloadAll"),
  downloadSelected: document.getElementById("downloadSelected"),
  dropZone: document.getElementById("dropZone"),
  textForm: document.getElementById("textForm"),
  textInput: document.getElementById("textInput"),
  searchInput: document.getElementById("searchInput"),
  typeFilter: document.getElementById("typeFilter"),
  favoriteFolder: document.getElementById("favoriteFolder"),
  trashFolder: document.getElementById("trashFolder"),
  emptyTrash: document.getElementById("emptyTrash"),
  folderFilter: document.getElementById("folderFilter"),
  createFolder: document.getElementById("createFolder"),
  columnRange: document.getElementById("columnRange"),
  sizeRange: document.getElementById("sizeRange"),
  settingsButton: document.getElementById("settingsButton"),
  settingsPanel: document.getElementById("settingsPanel"),
  settingsClose: document.getElementById("settingsClose"),
  floatEnabled: document.getElementById("floatEnabled"),
  webdavEnabled: document.getElementById("webdavEnabled"),
  webdavUrl: document.getElementById("webdavUrl"),
  webdavUsername: document.getElementById("webdavUsername"),
  webdavPassword: document.getElementById("webdavPassword"),
  webdavDir: document.getElementById("webdavDir"),
  webdavAutoSyncMinutes: document.getElementById("webdavAutoSyncMinutes"),
  webdavSave: document.getElementById("webdavSave"),
  webdavTest: document.getElementById("webdavTest"),
  webdavSyncAll: document.getElementById("webdavSyncAll"),
  webdavStatus: document.getElementById("webdavStatus"),
  assetList: document.getElementById("assetList"),
  assetTemplate: document.getElementById("assetTemplate")
};

let dbPromise;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  return dbPromise;
}

async function withStore(mode, callback) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, mode);
    const store = tx.objectStore(STORE_NAME);
    const result = callback(store);
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
  });
}

async function getAllAssets() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result.sort((a, b) => b.createdAt - a.createdAt));
    request.onerror = () => reject(request.error);
  });
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

async function loadUiState() {
  const result = await storageGet([SETTINGS_KEY, FOLDERS_KEY]);
  const savedSettings = result[SETTINGS_KEY] || {};
  state.settings = {
    ...state.settings,
    ...savedSettings,
    webdav: {
      ...state.settings.webdav,
      ...(savedSettings.webdav || {})
    }
  };
  state.folders = result[FOLDERS_KEY] || [];
  applyBoardSettings();
}

async function saveUiState() {
  await storageSet({
    [SETTINGS_KEY]: state.settings,
    [FOLDERS_KEY]: state.folders
  });
}

function applyBoardSettings() {
  document.documentElement.style.setProperty("--columns", String(state.settings.columns));
  document.documentElement.style.setProperty("--card-size", `${state.settings.cardSize}px`);
  els.columnRange.value = String(state.settings.columns);
  els.sizeRange.value = String(state.settings.cardSize);
  els.floatEnabled.checked = Boolean(state.settings.floatEnabled);
  const webdav = state.settings.webdav || {};
  els.webdavEnabled.checked = Boolean(webdav.enabled);
  els.webdavUrl.value = webdav.url || "";
  els.webdavUsername.value = webdav.username || "";
  els.webdavPassword.value = webdav.password || "";
  els.webdavDir.value = webdav.dir || "yun-lou";
  els.webdavAutoSyncMinutes.value = String(webdav.autoSyncMinutes || 0);
}

async function saveAsset(asset, rerender = true) {
  await withStore("readwrite", (store) => store.put(asset));
  if (rerender) await refresh();
  syncAssetToWebDav(asset.id);
}

function setWebDavStatus(text) {
  els.webdavStatus.textContent = text;
}

function readWebDavSettings() {
  return {
    enabled: els.webdavEnabled.checked,
    url: els.webdavUrl.value.trim(),
    username: els.webdavUsername.value.trim(),
    password: els.webdavPassword.value,
    dir: els.webdavDir.value.trim() || "yun-lou",
    autoSyncMinutes: Number(els.webdavAutoSyncMinutes.value || 0)
  };
}

async function saveWebDavSettings() {
  state.settings.webdav = readWebDavSettings();
  await saveUiState();
  await sendRuntimeMessage({ type: "WEBDAV_CONFIGURE_AUTO_SYNC" });
  setWebDavStatus("WebDAV 设置已保存");
}

async function sendRuntimeMessage(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    return { ok: false, error: error.message || "请求失败" };
  }
}

function syncAssetToWebDav(id) {
  if (!state.settings.webdav?.enabled) return;
  sendRuntimeMessage({ type: "WEBDAV_SYNC_ASSET", id }).catch(() => {});
}

async function deleteAssetsFromWebDav(ids) {
  if (!state.settings.webdav?.enabled || !ids.length) return true;
  const response = await sendRuntimeMessage({ type: "WEBDAV_DELETE_ASSETS", ids });
  if (response?.ok) return true;
  alert(response?.error || "删除云端素材失败，请检查 WebDAV 后再重试。");
  return false;
}

async function testWebDav() {
  await saveWebDavSettings();
  setWebDavStatus("正在测试 WebDAV...");
  const response = await sendRuntimeMessage({ type: "WEBDAV_TEST" });
  setWebDavStatus(response?.ok ? "WebDAV 连接正常" : `WebDAV 连接失败：${response?.error || "未知错误"}`);
}

async function syncAllToWebDav() {
  await saveWebDavSettings();
  els.webdavSyncAll.disabled = true;
  const originalText = els.webdavSyncAll.textContent;
  els.webdavSyncAll.textContent = "同步中";
  setWebDavStatus("正在按本地素材同步到 WebDAV...");
  const response = await sendRuntimeMessage({ type: "WEBDAV_SYNC_ALL" });
  if (response?.ok) {
    setWebDavStatus(`同步完成：下载 ${response.pulled || 0} 个，上传 ${response.pushed || 0} 个，清理 ${response.deleted || 0} 个`);
    await refresh();
  } else {
    setWebDavStatus(`同步失败：${response?.error || "未知错误"}`);
  }
  els.webdavSyncAll.textContent = originalText;
  els.webdavSyncAll.disabled = false;
}

async function patchAsset(id, patch) {
  const asset = state.assets.find((item) => item.id === id);
  if (!asset) return;
  await saveAsset({ ...asset, ...patch, updatedAt: Date.now() });
}

async function updateTextAsset(id, text) {
  const value = text.trim();
  if (!value) return;
  await patchAsset(id, {
    name: value.slice(0, 32),
    text: value,
    size: new Blob([value]).size
  });
}

async function renameAsset(asset) {
  const next = prompt("输入新的素材名称", asset.name || "");
  if (next === null) return;
  const name = next.trim();
  if (!name) return;
  await patchAsset(asset.id, { name });
}

function startNameEdit(nameNode, asset) {
  if (asset.trashed || nameNode.querySelector("input")) return;
  const input = document.createElement("input");
  input.className = "asset-name-input";
  input.value = asset.name || "";
  nameNode.replaceChildren(input);
  input.focus();
  input.select();

  let done = false;
  const finish = async (save) => {
    if (done) return;
    done = true;
    const next = input.value.trim();
    nameNode.textContent = asset.name || "未命名素材";
    if (save && next && next !== asset.name) {
      await patchAsset(asset.id, { name: next });
    }
  };

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      finish(true);
    } else if (event.key === "Escape") {
      event.preventDefault();
      finish(false);
    }
  });
  input.addEventListener("blur", () => finish(true));
}

async function deleteAsset(id) {
  const asset = state.assets.find((item) => item.id === id);
  if (!asset) return;
  if (asset.trashed) {
    if (!confirm("确定彻底删除这个素材吗？")) return;
    if (!(await deleteAssetsFromWebDav([id]))) return;
    await withStore("readwrite", (store) => store.delete(id));
    revokeObjectUrl(id);
  } else {
    await saveAsset({ ...asset, trashed: true, trashedAt: Date.now(), updatedAt: Date.now() }, false);
  }
  state.selected.delete(id);
  await refresh();
}

async function restoreAsset(id) {
  const asset = state.assets.find((item) => item.id === id);
  if (!asset) return;
  await saveAsset({ ...asset, trashed: false, trashedAt: 0, updatedAt: Date.now() });
}

async function emptyTrash() {
  const trashedAssets = state.assets.filter((asset) => asset.trashed);
  if (!trashedAssets.length) return;
  if (!confirm(`确定清空回收站里的 ${trashedAssets.length} 个素材吗？这会同时删除云端存储。`)) return;
  if (!(await deleteAssetsFromWebDav(trashedAssets.map((asset) => asset.id)))) return;
  await withStore("readwrite", (store) => {
    for (const asset of trashedAssets) store.delete(asset.id);
  });
  for (const asset of trashedAssets) {
    revokeObjectUrl(asset.id);
    state.selected.delete(asset.id);
  }
  await refresh();
  syncAllToWebDav();
}

async function clearAssets() {
  if (!state.assets.length) return;
  if (!confirm("确定清空所有素材吗？")) return;
  await withStore("readwrite", (store) => store.clear());
  state.objectUrls.forEach((url) => URL.revokeObjectURL(url));
  state.objectUrls.clear();
  state.selected.clear();
  await refresh();
}

async function clearSelectedAssets() {
  const selectedAssets = state.assets.filter((asset) => state.selected.has(asset.id));
  if (!selectedAssets.length) return;
  if (!confirm(`确定清除已选的 ${selectedAssets.length} 个素材吗？`)) return;
  const trashedAssets = selectedAssets.filter((asset) => asset.trashed);
  if (trashedAssets.length) {
    if (!(await deleteAssetsFromWebDav(trashedAssets.map((asset) => asset.id)))) return;
  }
  const now = Date.now();
  await withStore("readwrite", (store) => {
    for (const asset of selectedAssets) {
      if (asset.trashed) {
        store.delete(asset.id);
        revokeObjectUrl(asset.id);
      } else {
        store.put({ ...asset, trashed: true, trashedAt: now, updatedAt: now });
      }
    }
  });
  state.selected.clear();
  await refresh();
}

async function deleteFolder(folderId) {
  const folder = state.folders.find((item) => item.id === folderId);
  if (!folder) return;
  if (!confirm(`删除文件夹“${folder.name}”？素材会移动到未分类。`)) return;
  state.folders = state.folders.filter((item) => item.id !== folderId);
  if (state.folderFilter === `folder:${folderId}`) state.folderFilter = "all";
  await saveUiState();
  for (const asset of state.assets.filter((item) => item.folderId === folderId)) {
    await saveAsset({ ...asset, folderId: "", updatedAt: Date.now() }, false);
  }
  await refresh();
}

function makeId() {
  return `${Date.now()}-${crypto.randomUUID()}`;
}

function detectKind(file) {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/")) return "video";
  return "file";
}

function formatBytes(bytes = 0) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function sanitizeFilename(name) {
  return (name || "material").replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 90) || "material";
}

function extensionFor(asset) {
  if (asset.kind === "text") return "txt";
  const fromName = asset.name?.match(/\.([a-z0-9]{2,8})$/i)?.[1];
  if (fromName) return fromName;
  const fromMime = asset.mime?.split("/")[1]?.replace("jpeg", "jpg").replace(/[^a-z0-9]+/gi, "") || "";
  return fromMime || "bin";
}

function folderName(id) {
  if (!id) return "未分类";
  return state.folders.find((folder) => folder.id === id)?.name || "未分类";
}

function revokeObjectUrl(id) {
  const oldUrl = state.objectUrls.get(id);
  if (oldUrl) URL.revokeObjectURL(oldUrl);
  state.objectUrls.delete(id);
}

function getObjectUrl(asset) {
  if (state.objectUrls.has(asset.id)) return state.objectUrls.get(asset.id);
  const blob = asset.kind === "text" ? new Blob([asset.text], { type: "text/plain;charset=utf-8" }) : asset.blob;
  const url = URL.createObjectURL(blob);
  state.objectUrls.set(asset.id, url);
  return url;
}

async function addFiles(files) {
  const folderId = state.folderFilter.startsWith("folder:") ? state.folderFilter.slice(7) : "";
  for (const file of files) {
    await saveAsset({
      id: makeId(),
      kind: detectKind(file),
      name: file.name || "未命名文件",
      mime: file.type || "application/octet-stream",
      size: file.size,
      blob: file,
      folderId,
      favorite: false,
      trashed: false,
      createdAt: Date.now()
    }, false);
  }
  await refresh();
}

async function addText(text, name = "文字片段") {
  const value = text.trim();
  if (!value) return;
  const folderId = state.folderFilter.startsWith("folder:") ? state.folderFilter.slice(7) : "";
  await saveAsset({
    id: makeId(),
    kind: "text",
    name: value.slice(0, 32) || name,
    text: value,
    size: new Blob([value]).size,
    folderId,
    favorite: false,
    trashed: false,
    createdAt: Date.now()
  });
}

function droppedRemoteAsset(dataTransfer) {
  const html = dataTransfer.getData("text/html");
  if (html?.trim()) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const media = doc.querySelector("img[src], video[src], source[src]");
    const src = media?.getAttribute("src") || "";
    if (src && !src.startsWith("data:") && !src.startsWith("blob:")) {
      return {
        url: src,
        name: media.getAttribute("alt") || media.getAttribute("title") || "",
        mime: media instanceof HTMLVideoElement || media.tagName.toLowerCase() === "video" ? "video/" : ""
      };
    }
  }
  const uri = dataTransfer.getData("text/uri-list").split("\n").find((line) => line && !line.startsWith("#")) || "";
  const plain = dataTransfer.getData("text/plain").trim();
  const url = uri || plain;
  if (!/^https?:\/\//i.test(url)) return null;
  if (!/\.(png|jpe?g|gif|webp|avif|svg|mp4|webm|mov)([?#].*)?$/i.test(url)) return null;
  return { url, name: url.split("/").pop()?.split(/[?#]/)[0] || "", mime: "" };
}

async function addRemoteAssetFromDrop(dataTransfer) {
  const remote = droppedRemoteAsset(dataTransfer);
  if (!remote) return false;
  const folderId = state.folderFilter.startsWith("folder:") ? state.folderFilter.slice(7) : "";
  const response = await chrome.runtime.sendMessage({
    type: "SAVE_REMOTE_ASSET",
    url: remote.url,
    mime: remote.mime,
    name: remote.name,
    folderId
  });
  if (!response?.ok) return false;
  await refresh();
  return true;
}

function getDroppedText(dataTransfer) {
  const plain = dataTransfer.getData("text/plain");
  if (plain?.trim()) return plain;
  const html = dataTransfer.getData("text/html");
  if (!html?.trim()) return "";
  const doc = new DOMParser().parseFromString(html, "text/html");
  return doc.body.textContent || "";
}

function getVisibleAssets() {
  const query = state.search.trim().toLowerCase();
  return state.assets.filter((asset) => {
    const matchesTrash = state.folderFilter === "trash" ? asset.trashed : !asset.trashed;
    if (!matchesTrash) return false;
    const matchesType = state.filter === "all" || asset.kind === state.filter;
    const matchesFolder =
      state.folderFilter === "all" ||
      state.folderFilter === "trash" ||
      state.folderFilter === "favorites" && asset.favorite ||
      state.folderFilter === "uncategorized" && !asset.folderId ||
      state.folderFilter.startsWith("folder:") && asset.folderId === state.folderFilter.slice(7);
    const haystack = `${asset.name || ""} ${asset.text || ""} ${folderName(asset.folderId)}`.toLowerCase();
    return matchesType && matchesFolder && (!query || haystack.includes(query));
  });
}

function renderFolderOptions() {
  const selected = state.folderFilter;
  const items = [
    ["uncategorized", "未分类"],
    ...state.folders.map((folder) => [`folder:${folder.id}`, folder.name])
  ];
  const hasSelected = selected === "all" || selected === "favorites" || selected === "trash" || items.some(([value]) => value === selected);
  if (!hasSelected) {
    state.folderFilter = "all";
  }
  els.folderFilter.replaceChildren(...items.map(([value, label]) => folderChip(value, label)));
}

function renderAssetFolderSelect(select, asset) {
  select.replaceChildren(
    option("", "未分类"),
    ...state.folders.map((folder) => option(folder.id, folder.name))
  );
  select.value = asset.folderId || "";
}

function option(value, label) {
  const node = document.createElement("option");
  node.value = value;
  node.textContent = label;
  return node;
}

function folderChip(value, label) {
  const node = document.createElement("button");
  node.type = "button";
  node.className = "folder-chip";
  node.dataset.value = value;
  node.role = "option";
  node.ariaSelected = String(state.folderFilter === value);
  node.classList.toggle("is-active", state.folderFilter === value);
  const labelNode = document.createElement("span");
  labelNode.textContent = label;
  node.append(labelNode);
  if (value.startsWith("folder:")) {
    const deleteButton = document.createElement("button");
    deleteButton.className = "folder-delete";
    deleteButton.type = "button";
    deleteButton.title = "删除文件夹";
    deleteButton.textContent = "×";
    node.append(deleteButton);
  }
  return node;
}

function renderTypeTabs() {
  for (const tab of els.typeFilter.querySelectorAll(".type-tab")) {
    tab.classList.toggle("is-active", tab.dataset.type === state.filter);
  }
  els.favoriteFolder.classList.toggle("is-active", state.folderFilter === "favorites");
  els.trashFolder.classList.toggle("is-active", state.folderFilter === "trash");
}

function renderSelectionState() {
  const activeAssets = state.assets.filter((asset) => !asset.trashed).length;
  const trashAssets = state.assets.filter((asset) => asset.trashed).length;
  els.countLabel.textContent = state.folderFilter === "trash"
    ? `回收站 ${trashAssets} 个素材，已选 ${state.selected.size} 个`
    : `${activeAssets} 个素材，已选 ${state.selected.size} 个`;
  els.downloadSelected.disabled = state.selected.size === 0;
  els.clearSelected.disabled = state.selected.size === 0;
}

function updateSelectedAssetCard(id, checked) {
  const card = els.assetList.querySelector(`.asset-card[data-id="${CSS.escape(id)}"]`);
  card?.classList.toggle("is-selected", checked);
  renderSelectionState();
}

function closeDownloadMenu() {
  const menuWrap = els.downloadMenu?.closest(".download-menu");
  menuWrap?.classList.remove("is-open");
  els.downloadMenuToggle?.setAttribute("aria-expanded", "false");
}

function closeDeleteMenu() {
  const menuWrap = els.deleteMenu?.closest(".danger-menu");
  menuWrap?.classList.remove("is-open");
  els.deleteMenuToggle?.setAttribute("aria-expanded", "false");
}

function closeActionMenus() {
  closeDownloadMenu();
  closeDeleteMenu();
}

function toggleActionMenu(menu, toggle, selector) {
  const menuWrap = menu?.closest(selector);
  const open = !menuWrap?.classList.contains("is-open");
  closeActionMenus();
  menuWrap?.classList.toggle("is-open", open);
  toggle?.setAttribute("aria-expanded", String(open));
}

function render() {
  renderFolderOptions();
  renderTypeTabs();
  const assets = getVisibleAssets();
  document.querySelector(".manager")?.classList.toggle("is-trash", state.folderFilter === "trash");
  renderSelectionState();
  els.assetList.replaceChildren();

  if (!assets.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = state.folderFilter === "trash"
      ? "回收站是空的"
      : state.assets.some((asset) => !asset.trashed) ? "没有匹配的素材" : "还没有素材，拖入或粘贴一些内容吧";
    els.assetList.append(empty);
    return;
  }

  for (const asset of assets) {
    const node = els.assetTemplate.content.firstElementChild.cloneNode(true);
    node.dataset.id = asset.id;
    node.dataset.kind = asset.kind;
    node.classList.toggle("is-selected", state.selected.has(asset.id));
    node.classList.toggle("is-trashed", Boolean(asset.trashed));

    const preview = node.querySelector(".preview");
    const name = node.querySelector(".asset-name");
    const meta = node.querySelector(".asset-meta");
    const editor = node.querySelector(".text-editor");
    const folderSelect = node.querySelector(".folder-select");
    const selectInput = node.querySelector(".select-input");
    const favoriteButton = node.querySelector(".favorite-button");
    const copyButton = node.querySelector(".copy-button");
    const renameButton = node.querySelector(".rename-button");
    const editButton = node.querySelector(".edit-button");
    const saveButton = node.querySelector(".save-button");
    const cancelButton = node.querySelector(".cancel-button");
    const restoreButton = node.querySelector(".restore-button");
    const downloadButton = node.querySelector(".download-button");
    const deleteButton = node.querySelector(".delete-button");

    name.textContent = asset.name || "未命名素材";
    name.title = "点击改名";
    meta.textContent = "";
    selectInput.checked = state.selected.has(asset.id);
    favoriteButton.textContent = asset.favorite ? "★" : "☆";
    favoriteButton.classList.toggle("is-active", Boolean(asset.favorite));
    renderAssetFolderSelect(folderSelect, asset);

    if (asset.kind === "image") {
      const img = document.createElement("img");
      img.alt = asset.name || "";
      img.src = getObjectUrl(asset);
      preview.append(img);
    } else if (asset.kind === "video") {
      const video = document.createElement("video");
      video.src = getObjectUrl(asset);
      video.muted = true;
      video.controls = true;
      video.playsInline = true;
      preview.append(video);
    } else if (asset.kind === "text") {
      preview.classList.add("text-preview");
      preview.textContent = asset.text || "";
      editor.value = asset.text || "";
    } else {
      preview.textContent = "FILE";
    }

    const sourceUrl = asset.sourceUrl || asset.url || "";
    if (sourceUrl) {
      const sourceButton = document.createElement("button");
      sourceButton.type = "button";
      sourceButton.className = "source-link-button";
      sourceButton.textContent = "打开来源";
      sourceButton.title = sourceUrl;
      sourceButton.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        window.open(sourceUrl, "_blank", "noopener");
      });
      node.append(sourceButton);
    }

    selectInput.addEventListener("change", () => {
      if (selectInput.checked) state.selected.add(asset.id);
      else state.selected.delete(asset.id);
      updateSelectedAssetCard(asset.id, selectInput.checked);
    });
    favoriteButton.addEventListener("click", () => patchAsset(asset.id, { favorite: !asset.favorite }));
    folderSelect.addEventListener("change", () => patchAsset(asset.id, { folderId: folderSelect.value }));
    copyButton.addEventListener("click", () => copyAsset(asset));
    name.addEventListener("click", () => startNameEdit(name, asset));
    renameButton.addEventListener("click", () => renameAsset(asset));
    const startTextEdit = () => {
      if (asset.kind !== "text" || asset.trashed) return;
      node.draggable = false;
      node.classList.add("is-editing");
      editor.focus();
    };
    preview.addEventListener("click", startTextEdit);
    editButton.addEventListener("click", startTextEdit);
    cancelButton.addEventListener("click", () => {
      editor.value = asset.text || "";
      node.classList.remove("is-editing");
      node.draggable = !asset.trashed;
    });
    saveButton.addEventListener("click", () => updateTextAsset(asset.id, editor.value));
    downloadButton.addEventListener("click", () => downloadAsset(asset));
    restoreButton.addEventListener("click", () => restoreAsset(asset.id));
    deleteButton.textContent = asset.trashed ? "彻底删除" : "删除";
    deleteButton.addEventListener("click", () => deleteAsset(asset.id));
    if (asset.trashed) node.draggable = false;
    node.addEventListener("dragstart", (event) => startDrag(event, asset));
    els.assetList.append(node);
  }
}

async function refresh() {
  const scrollTop = window.scrollY;
  state.assets = await getAllAssets();
  for (const id of [...state.selected]) {
    if (!state.assets.some((asset) => asset.id === id)) state.selected.delete(id);
  }
  render();
  requestAnimationFrame(() => window.scrollTo({ top: scrollTop, left: 0 }));
}

async function copyAsset(asset) {
  if (asset.kind === "text") {
    await navigator.clipboard.writeText(asset.text || "");
    return;
  }
  if (asset.kind === "image" && window.ClipboardItem) {
    try {
      await navigator.clipboard.write([new ClipboardItem({ [asset.mime]: asset.blob })]);
      return;
    } catch {
      await navigator.clipboard.writeText(asset.name || "");
      return;
    }
  }
  await navigator.clipboard.writeText(getObjectUrl(asset));
}

function downloadAsset(asset, index = 1) {
  const url = getObjectUrl(asset);
  const ext = extensionFor(asset);
  const baseName = sanitizeFilename(asset.name).replace(new RegExp(`\\.${ext}$`, "i"), "");
  const folder = sanitizeFilename(folderName(asset.folderId));
  const filename = `云篓/${folder}/${String(index).padStart(3, "0")}-${baseName}.${ext}`;

  if (chrome.downloads?.download) {
    chrome.downloads.download({ url, filename, saveAs: false });
    return;
  }
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
}

function downloadAssets(assets) {
  for (const [index, asset] of assets.entries()) {
    downloadAsset(asset, index + 1);
  }
}

function downloadSelectedAssets() {
  const assets = state.assets.filter((asset) => state.selected.has(asset.id) && !asset.trashed);
  downloadAssets(assets);
}

function downloadAllAssets() {
  downloadAssets(state.assets.filter((asset) => !asset.trashed).slice().reverse());
}

function startDrag(event, asset) {
  event.dataTransfer.effectAllowed = "copy";
  if (asset.kind === "text") {
    event.dataTransfer.setData("text/plain", asset.text || "");
    event.dataTransfer.setData("application/material-hub-text", asset.text || "");
    event.dataTransfer.setData("text/html", escapeHtml(asset.text || "").replaceAll("\n", "<br>"));
    return;
  }
  event.dataTransfer.setData(DRAG_ASSET_MIME, asset.id);
  event.dataTransfer.setData("application/material-hub-kind", asset.kind);
  try {
    event.dataTransfer.items.add(new File([asset.blob], asset.name || "material", { type: asset.mime }));
  } catch {
    // Some pages or browser versions reject programmatic file drag data.
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

async function handleIncomingData(dataTransfer) {
  const files = [...dataTransfer.files];
  if (files.length) {
    await addFiles(files);
    return;
  }
  if (await addRemoteAssetFromDrop(dataTransfer)) return;
  await addText(getDroppedText(dataTransfer));
}

async function createFolder() {
  const name = prompt("输入文件夹名称");
  if (!name?.trim()) return;
  const folder = {
    id: crypto.randomUUID(),
    name: name.trim(),
    createdAt: Date.now()
  };
  state.folders.push(folder);
  state.folderFilter = `folder:${folder.id}`;
  await saveUiState();
  render();
}

function wireEvents() {
  ["dragenter", "dragover"].forEach((type) => {
    document.addEventListener(type, (event) => {
      event.preventDefault();
      document.body.classList.add("is-dragging");
      els.dropZone.classList.add("is-over");
    });
  });

  ["dragleave", "drop"].forEach((type) => {
    document.addEventListener(type, () => {
      document.body.classList.remove("is-dragging");
      els.dropZone.classList.remove("is-over");
    });
  });

  document.addEventListener("drop", async (event) => {
    event.preventDefault();
    await handleIncomingData(event.dataTransfer);
  });

  document.addEventListener("paste", async (event) => {
    const files = [...event.clipboardData.files];
    if (files.length) {
      await addFiles(files);
      return;
    }
    await addText(event.clipboardData.getData("text/plain"));
  });

  els.textForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await addText(els.textInput.value);
    els.textInput.value = "";
  });

  els.searchInput.addEventListener("input", () => {
    state.search = els.searchInput.value;
    render();
  });

  els.typeFilter.addEventListener("click", (event) => {
    const tab = event.target.closest(".type-tab");
    if (!tab) return;
    state.filter = tab.dataset.type || "all";
    if (state.filter === "all") state.folderFilter = "all";
    render();
  });

  els.favoriteFolder.addEventListener("click", () => {
    state.folderFilter = state.folderFilter === "favorites" ? "all" : "favorites";
    render();
  });

  els.trashFolder.addEventListener("click", () => {
    state.folderFilter = state.folderFilter === "trash" ? "all" : "trash";
    render();
  });

  els.folderFilter.addEventListener("click", (event) => {
    const deleteButton = event.target.closest(".folder-delete");
    if (deleteButton) {
      const chip = deleteButton.closest(".folder-chip");
      deleteFolder(chip.dataset.value.slice(7));
      return;
    }
    const chip = event.target.closest(".folder-chip");
    if (!chip) return;
    state.folderFilter = chip.dataset.value || "all";
    render();
  });

  els.folderFilter.addEventListener("mouseover", (event) => {
    const chip = event.target.closest(".folder-chip[data-value^='folder:']");
    if (!chip || chip.deleteTimer) return;
    chip.deleteTimer = window.setTimeout(() => chip.classList.add("is-deletable"), 3000);
  });

  els.folderFilter.addEventListener("mouseout", (event) => {
    const chip = event.target.closest(".folder-chip[data-value^='folder:']");
    if (!chip || chip.contains(event.relatedTarget)) return;
    window.clearTimeout(chip.deleteTimer);
    chip.deleteTimer = 0;
    chip.classList.remove("is-deletable");
  });

  els.columnRange.addEventListener("input", async () => {
    state.settings.columns = Number(els.columnRange.value);
    applyBoardSettings();
    await saveUiState();
  });

  els.sizeRange.addEventListener("input", async () => {
    state.settings.cardSize = Number(els.sizeRange.value);
    applyBoardSettings();
    await saveUiState();
  });

  els.settingsButton.addEventListener("click", () => {
    els.settingsPanel.classList.toggle("is-open");
  });

  els.settingsClose.addEventListener("click", () => {
    els.settingsPanel.classList.remove("is-open");
  });

  els.floatEnabled.addEventListener("change", async () => {
    state.settings.floatEnabled = els.floatEnabled.checked;
    await saveUiState();
  });

  els.webdavSave.addEventListener("click", saveWebDavSettings);
  els.webdavTest.addEventListener("click", testWebDav);
  els.webdavSyncAll.addEventListener("click", syncAllToWebDav);

  els.createFolder.addEventListener("click", createFolder);
  els.emptyTrash.addEventListener("click", emptyTrash);
  els.downloadMenuToggle.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleActionMenu(els.downloadMenu, els.downloadMenuToggle, ".download-menu");
  });
  els.downloadMenu.addEventListener("click", (event) => event.stopPropagation());
  els.deleteMenuToggle.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleActionMenu(els.deleteMenu, els.deleteMenuToggle, ".danger-menu");
  });
  els.deleteMenu.addEventListener("click", (event) => event.stopPropagation());
  document.addEventListener("click", closeActionMenus);
  els.downloadSelected.addEventListener("click", () => {
    closeActionMenus();
    downloadSelectedAssets();
  });
  els.downloadAll.addEventListener("click", () => {
    closeActionMenus();
    downloadAllAssets();
  });
  els.clearSelected.addEventListener("click", () => {
    closeActionMenus();
    clearSelectedAssets();
  });
  els.clearAll.addEventListener("click", () => {
    closeActionMenus();
    clearAssets();
  });

  chrome.runtime?.onMessage?.addListener((message) => {
    if (message?.type === "ASSETS_CHANGED") refresh();
    if (message?.type === "REQUEST_CLOSE_SIDE_PANEL") window.close();
  });
}

(async function init() {
  await loadUiState();
  wireEvents();
  await refresh();
})();
