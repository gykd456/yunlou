const DB_NAME = "material-hub";
const STORE_NAME = "assets";
const DB_VERSION = 1;
const MAX_DROP_BRIDGE_SIZE = 50 * 1024 * 1024;
const SETTINGS_KEY = "materialHubSettings";
const WEBDAV_SYNC_STATE_KEY = "materialHubWebDavSyncState";
const WEBDAV_AUTO_SYNC_ALARM = "materialHubWebDavAutoSync";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  configureWebDavAutoSync().catch(() => {});
});

chrome.runtime.onStartup?.addListener(() => {
  configureWebDavAutoSync().catch(() => {});
});

chrome.alarms?.onAlarm?.addListener((alarm) => {
  if (alarm.name !== WEBDAV_AUTO_SYNC_ALARM) return;
  syncAllToWebDav().catch(() => {});
});

let dbPromise;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  return dbPromise;
}

async function saveAsset(asset) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    let savedAsset = asset;
    const allRequest = store.getAll();
    allRequest.onsuccess = () => {
      const existing = allRequest.result.find((item) => {
        if (asset.kind === "text") return item.kind === "text" && item.text === asset.text;
        return asset.url && item.url === asset.url;
      });
      savedAsset = existing ? { ...existing, createdAt: Date.now() } : asset;
      store.put(savedAsset);
    };
    tx.oncomplete = () => resolve(savedAsset);
    tx.onerror = () => reject(tx.error);
  });
}

async function getAllAssets() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result.sort((a, b) => b.createdAt - a.createdAt));
    request.onerror = () => reject(request.error);
  });
}

async function getAsset(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

async function putAsset(asset) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(asset);
    tx.oncomplete = () => resolve(asset);
    tx.onerror = () => reject(tx.error);
  });
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

async function getWebDavSettings() {
  const result = await storageGet([SETTINGS_KEY]);
  return result[SETTINGS_KEY]?.webdav || {};
}

async function getWebDavSyncState(settings) {
  const result = await storageGet([WEBDAV_SYNC_STATE_KEY]);
  const key = `${settings.url || ""}|${settings.dir || "yun-lou"}`;
  return result[WEBDAV_SYNC_STATE_KEY]?.[key] || { knownIds: [], lastSyncAt: 0 };
}

async function setWebDavSyncState(settings, assets) {
  const result = await storageGet([WEBDAV_SYNC_STATE_KEY]);
  const allState = result[WEBDAV_SYNC_STATE_KEY] || {};
  const key = `${settings.url || ""}|${settings.dir || "yun-lou"}`;
  allState[key] = {
    knownIds: assets.map((asset) => asset.id),
    lastSyncAt: Date.now()
  };
  await storageSet({ [WEBDAV_SYNC_STATE_KEY]: allState });
}

async function configureWebDavAutoSync() {
  const settings = await getWebDavSettings();
  await chrome.alarms?.clear?.(WEBDAV_AUTO_SYNC_ALARM);
  const interval = Number(settings.autoSyncMinutes || 0);
  if (!settings.enabled || interval <= 0) return;
  chrome.alarms?.create?.(WEBDAV_AUTO_SYNC_ALARM, {
    delayInMinutes: interval,
    periodInMinutes: interval
  });
}

function assertWebDavSettings(settings) {
  if (!settings.enabled) throw new Error("WebDAV 未开启");
  if (!settings.url) throw new Error("缺少 WebDAV 地址");
}

function webDavHeaders(settings, extra = {}) {
  const headers = { ...extra };
  if (settings.username || settings.password) {
    headers.Authorization = `Basic ${btoa(unescape(encodeURIComponent(`${settings.username || ""}:${settings.password || ""}`)))}`;
  }
  return headers;
}

function cleanPath(value) {
  return String(value || "").replace(/^\/+|\/+$/g, "");
}

function joinWebDavUrl(baseUrl, ...parts) {
  const base = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const path = parts
    .map(cleanPath)
    .filter(Boolean)
    .flatMap((part) => part.split("/").filter(Boolean))
    .map(encodeURIComponent)
    .join("/");
  return new URL(path, base).href;
}

function extensionFromMime(mime, kind) {
  const normalized = String(mime || "").split(";")[0].trim().toLowerCase();
  const map = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/svg+xml": "svg",
    "image/bmp": "bmp",
    "image/avif": "avif",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/ogg": "ogv",
    "video/quicktime": "mov",
    "text/plain": "txt"
  };
  if (map[normalized]) return map[normalized];
  if (kind === "text") return "txt";
  if (kind === "image") return "png";
  if (kind === "video") return "mp4";
  return "bin";
}

function extensionFromName(name) {
  const match = String(name || "").trim().match(/\.([a-z0-9]{1,8})$/i);
  return match ? match[1].toLowerCase() : "";
}

function safeRemoteName(asset) {
  const extension = extensionFromName(asset.name) || extensionFromMime(asset.mime || asset.blob?.type, asset.kind);
  const raw = asset.name || asset.id || "material";
  let cleaned = raw.replace(/[\\/:*?"<>|#%&{}$!'@+`=]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 90) || "material";
  if (extension) cleaned = cleaned.replace(new RegExp(`\\.${extension}$`, "i"), "");
  return `${asset.id}-${cleaned}.${extension || "bin"}`;
}

function assetBlob(asset) {
  if (asset.kind === "text") {
    return new Blob([asset.text || ""], { type: "text/plain;charset=utf-8" });
  }
  if (!asset.blob) throw new Error(`素材缺少文件数据：${asset.name || asset.id}`);
  return asset.blob;
}

async function webDavRequest(settings, method, url, body, headers = {}) {
  const response = await fetch(url, {
    method,
    headers: webDavHeaders(settings, headers),
    body
  });
  if (!response.ok && !(method === "MKCOL" && response.status === 405)) {
    throw new Error(`${method} ${response.status}`);
  }
  return response;
}

async function webDavGet(settings, url) {
  const response = await fetch(url, {
    method: "GET",
    headers: webDavHeaders(settings)
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`GET ${response.status}`);
  return response;
}

async function deleteWebDavPath(settings, path) {
  if (!path) return false;
  const response = await fetch(joinWebDavUrl(settings.url, path), {
    method: "DELETE",
    headers: webDavHeaders(settings)
  });
  if (response.ok || response.status === 404) return true;
  throw new Error(`DELETE ${response.status}`);
}

async function ensureWebDavDir(settings, ...parts) {
  const segments = parts.map(cleanPath).filter(Boolean).flatMap((part) => part.split("/").filter(Boolean));
  let current = "";
  for (const segment of segments) {
    current = current ? `${current}/${segment}` : segment;
    await webDavRequest(settings, "MKCOL", joinWebDavUrl(settings.url, current));
  }
}

function remoteAssetPath(settings, asset) {
  const dir = cleanPath(settings.dir || "yun-lou");
  return `${dir}/assets/${safeRemoteName(asset)}`;
}

async function uploadAssetToWebDav(asset, settings) {
  assertWebDavSettings(settings);
  await ensureWebDavDir(settings, settings.dir || "yun-lou", "assets");
  const path = remoteAssetPath(settings, asset);
  await webDavRequest(
    settings,
    "PUT",
    joinWebDavUrl(settings.url, path),
    assetBlob(asset),
    { "Content-Type": asset.mime || asset.blob?.type || "application/octet-stream" }
  );
  return path;
}

function indexAsset(asset, settings) {
  const blobSize = asset.kind === "text" ? new Blob([asset.text || ""]).size : asset.size;
  return {
    id: asset.id,
    kind: asset.kind,
    name: asset.name || "",
    mime: asset.kind === "text" ? "text/plain;charset=utf-8" : asset.mime || "",
    size: blobSize || 0,
    folderId: asset.folderId || "",
    favorite: Boolean(asset.favorite),
    trashed: Boolean(asset.trashed),
    trashedAt: asset.trashedAt || 0,
    sourceUrl: asset.sourceUrl || asset.url || "",
    createdAt: asset.createdAt || 0,
    updatedAt: asset.updatedAt || 0,
    path: remoteAssetPath(settings, asset)
  };
}

async function uploadIndexToWebDav(assets, settings, remoteItems = null) {
  assertWebDavSettings(settings);
  await ensureWebDavDir(settings, settings.dir || "yun-lou");
  const localItems = assets.map((asset) => indexAsset(asset, settings));
  const localIds = new Set(localItems.map((item) => item.id));
  if (!Array.isArray(remoteItems)) {
    const remoteIndex = await downloadIndexFromWebDav(settings).catch(() => ({ assets: [] }));
    remoteItems = Array.isArray(remoteIndex.assets) ? remoteIndex.assets : [];
  }
  const preservedRemoteItems = remoteItems.filter((item) => item?.id && !localIds.has(item.id));
  const index = {
    app: "云篓",
    version: 1,
    updatedAt: new Date().toISOString(),
    assets: [...preservedRemoteItems, ...localItems]
  };
  await webDavRequest(
    settings,
    "PUT",
    joinWebDavUrl(settings.url, settings.dir || "yun-lou", "index.json"),
    new Blob([JSON.stringify(index, null, 2)], { type: "application/json;charset=utf-8" }),
    { "Content-Type": "application/json;charset=utf-8" }
  );
}

async function downloadIndexFromWebDav(settings) {
  assertWebDavSettings(settings);
  const response = await webDavGet(settings, joinWebDavUrl(settings.url, settings.dir || "yun-lou", "index.json"));
  if (!response) return { assets: [] };
  return response.json();
}

async function downloadAssetFromWebDav(item, settings) {
  if (!item?.id || !item.path) return null;
  const response = await webDavGet(settings, joinWebDavUrl(settings.url, item.path));
  if (!response) return null;
  const blob = await response.blob();
  const base = {
    id: item.id,
    kind: item.kind || "file",
    name: item.name || "material",
    mime: item.mime || blob.type || "application/octet-stream",
    size: item.size || blob.size,
    folderId: item.folderId || "",
    favorite: Boolean(item.favorite),
    trashed: Boolean(item.trashed),
    trashedAt: item.trashedAt || 0,
    sourceUrl: item.sourceUrl || "",
    createdAt: item.createdAt || Date.now(),
    updatedAt: item.updatedAt || 0
  };
  if (base.kind === "text") {
    return {
      ...base,
      text: await blob.text(),
      size: blob.size
    };
  }
  return {
    ...base,
    blob,
    size: blob.size
  };
}

async function pullAllFromWebDav(settings) {
  const index = await downloadIndexFromWebDav(settings);
  const remoteAssets = Array.isArray(index.assets) ? index.assets : [];
  let pulled = 0;
  for (const item of remoteAssets) {
    const local = await getAsset(item.id);
    const localTime = local?.updatedAt || local?.createdAt || 0;
    const remoteTime = item.updatedAt || item.createdAt || 0;
    if (local && localTime >= remoteTime && (local.kind === "text" ? local.text : local.blob)) continue;
    const asset = await downloadAssetFromWebDav(item, settings);
    if (!asset) continue;
    await putAsset(asset);
    pulled += 1;
  }
  return pulled;
}

async function syncAssetToWebDav(id) {
  const settings = await getWebDavSettings();
  if (!settings.enabled) return false;
  const asset = await getAsset(id);
  if (!asset) throw new Error("素材不存在");
  const remoteIndex = await downloadIndexFromWebDav(settings).catch(() => ({ assets: [] }));
  const remoteItems = Array.isArray(remoteIndex.assets) ? remoteIndex.assets : [];
  const previousItem = remoteItems.find((item) => item?.id === asset.id);
  const nextPath = remoteAssetPath(settings, asset);
  await uploadAssetToWebDav(asset, settings);
  if (previousItem?.path && previousItem.path !== nextPath) {
    await deleteWebDavPath(settings, previousItem.path).catch(() => {});
  }
  const assets = await getAllAssets();
  await uploadIndexToWebDav(assets, settings, remoteItems);
  await setWebDavSyncState(settings, assets);
  return true;
}

async function syncAllToWebDav() {
  const settings = await getWebDavSettings();
  assertWebDavSettings(settings);
  let assets = await getAllAssets();
  const localById = new Map(assets.map((asset) => [asset.id, asset]));
  const remoteIndex = await downloadIndexFromWebDav(settings).catch(() => ({ assets: [] }));
  const remoteItems = Array.isArray(remoteIndex.assets) ? remoteIndex.assets : [];
  let pulled = 0;
  let deleted = 0;

  for (const item of remoteItems) {
    if (!item?.id || !item.path) continue;
    const local = localById.get(item.id);
    const localTime = local?.updatedAt || local?.createdAt || 0;
    const remoteTime = item.updatedAt || item.createdAt || 0;
    if (local && localTime >= remoteTime && (local.kind === "text" ? local.text : local.blob)) continue;

    const asset = await downloadAssetFromWebDav(item, settings);
    if (!asset) continue;
    await putAsset(asset);
    localById.set(asset.id, asset);
    pulled += 1;
  }

  assets = await getAllAssets();
  const previousItemsById = new Map(remoteItems.filter((item) => item?.id).map((item) => [item.id, item]));
  for (const asset of assets) {
    const previousItem = previousItemsById.get(asset.id);
    const nextPath = remoteAssetPath(settings, asset);
    await uploadAssetToWebDav(asset, settings);
    if (previousItem?.path && previousItem.path !== nextPath) {
      await deleteWebDavPath(settings, previousItem.path).catch(() => {});
    }
  }
  await uploadIndexToWebDav(assets, settings, remoteItems);
  await setWebDavSyncState(settings, assets);
  return { pulled, pushed: assets.length, deleted };
}

async function deleteAssetsFromWebDav(ids) {
  const settings = await getWebDavSettings();
  if (!settings.enabled) return { deleted: 0 };
  const deleteIds = new Set((Array.isArray(ids) ? ids : []).filter(Boolean));
  if (!deleteIds.size) return { deleted: 0 };

  assertWebDavSettings(settings);
  const remoteIndex = await downloadIndexFromWebDav(settings).catch(() => ({ assets: [] }));
  const remoteItems = Array.isArray(remoteIndex.assets) ? remoteIndex.assets : [];
  const deleteItems = remoteItems.filter((item) => item?.id && deleteIds.has(item.id));
  let deleted = 0;

  for (const item of deleteItems) {
    if (!item.path) continue;
    if (await deleteWebDavPath(settings, item.path)) deleted += 1;
  }

  const remainingItems = remoteItems.filter((item) => !item?.id || !deleteIds.has(item.id));
  const localAssets = (await getAllAssets()).filter((asset) => !deleteIds.has(asset.id));
  await uploadIndexToWebDav(localAssets, settings, remainingItems);
  await setWebDavSyncState(settings, localAssets);
  return { deleted };
}

async function testWebDav() {
  const settings = await getWebDavSettings();
  assertWebDavSettings(settings);
  await ensureWebDavDir(settings, settings.dir || "yun-lou");
  const testUrl = joinWebDavUrl(settings.url, settings.dir || "yun-lou", ".connection-test.txt");
  await webDavRequest(settings, "PUT", testUrl, new Blob(["ok"], { type: "text/plain" }), { "Content-Type": "text/plain" });
  await fetch(testUrl, { method: "DELETE", headers: webDavHeaders(settings) }).catch(() => {});
}

async function assetForDrop(id) {
  const asset = await getAsset(id);
  if (!asset) throw new Error("素材不存在");
  if (asset.kind === "text") {
    return {
      id: asset.id,
      kind: asset.kind,
      name: asset.name || "文字片段.txt",
      mime: "text/plain;charset=utf-8",
      text: asset.text || ""
    };
  }
  if (!asset.blob) throw new Error("素材缺少文件数据");
  if (asset.blob.size > MAX_DROP_BRIDGE_SIZE) {
    throw new Error("素材过大，请使用下载后上传");
  }
  const mime = asset.mime || asset.blob.type || "application/octet-stream";
  const bytes = new Uint8Array(await asset.blob.arrayBuffer());
  return {
    id: asset.id,
    kind: asset.kind,
    name: asset.name || "material",
    mime,
    dataUrl: `data:${mime};base64,${bytesToBase64(bytes)}`
  };
}

function makeId() {
  return `${Date.now()}-${crypto.randomUUID()}`;
}

function filenameFromUrl(url, fallback) {
  try {
    const parsed = new URL(url);
    const name = decodeURIComponent(parsed.pathname.split("/").filter(Boolean).pop() || "");
    return name || fallback;
  } catch {
    return fallback;
  }
}

function detectKind(mime) {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  return "file";
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "OPEN_SIDE_PANEL") {
    (async () => {
      const windowId = sender.tab?.windowId;
      const tabId = sender.tab?.id;
      if (tabId && chrome.sidePanel?.open) {
        await chrome.sidePanel.open({ tabId });
      } else if (windowId && chrome.sidePanel?.open) {
        await chrome.sidePanel.open({ windowId });
      } else {
        throw new Error("当前浏览器不支持从网页打开侧边栏");
      }
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "打开侧边栏失败" }));
    return true;
  }

  if (message?.type === "CLOSE_SIDE_PANEL") {
    chrome.runtime.sendMessage({ type: "REQUEST_CLOSE_SIDE_PANEL" }).catch(() => {});
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "WEBDAV_TEST") {
    (async () => {
      await testWebDav();
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "连接失败" }));
    return true;
  }

  if (message?.type === "WEBDAV_CONFIGURE_AUTO_SYNC") {
    (async () => {
      await configureWebDavAutoSync();
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "自动同步设置失败" }));
    return true;
  }

  if (message?.type === "WEBDAV_SYNC_ASSET") {
    (async () => {
      const synced = await syncAssetToWebDav(message.id);
      sendResponse({ ok: true, synced });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "同步失败" }));
    return true;
  }

  if (message?.type === "WEBDAV_SYNC_ALL") {
    (async () => {
      const result = await syncAllToWebDav();
      sendResponse({ ok: true, ...result });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "同步失败" }));
    return true;
  }

  if (message?.type === "WEBDAV_DELETE_ASSETS") {
    (async () => {
      const result = await deleteAssetsFromWebDav(message.ids || []);
      sendResponse({ ok: true, ...result });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "删除云端素材失败" }));
    return true;
  }

  if (message?.type === "GET_ASSET_FOR_DROP") {
    (async () => {
      const asset = await assetForDrop(message.id);
      sendResponse({ ok: true, asset });
    })().catch((error) => {
      sendResponse({ ok: false, error: error.message || "拖拽失败" });
    });
    return true;
  }

  if (message?.type === "SAVE_TEXT_ASSET") {
    (async () => {
      const text = String(message.text || "").trim();
      if (!text) throw new Error("没有可保存的文字");
      const asset = await saveAsset({
        id: makeId(),
        kind: "text",
        name: text.slice(0, 32),
        text,
        size: new Blob([text]).size,
        folderId: message.folderId || "",
        trashed: false,
        trashedAt: 0,
        sourceUrl: message.pageUrl || sender.tab?.url || "",
        createdAt: Date.now()
      });
      syncAssetToWebDav(asset.id).catch(() => {});
      chrome.runtime.sendMessage({ type: "ASSETS_CHANGED" }).catch(() => {});
      sendResponse({ ok: true });
    })().catch((error) => sendResponse({ ok: false, error: error.message || "保存失败" }));
    return true;
  }

  if (message?.type !== "SAVE_REMOTE_ASSET") return false;

  (async () => {
    const response = await fetch(message.url, { credentials: "include" });
    if (!response.ok) throw new Error(`保存失败：${response.status}`);

    const blob = await response.blob();
    const mime = blob.type || response.headers.get("content-type") || message.mime || "application/octet-stream";
    const kind = detectKind(mime);
    const fallbackName = kind === "video" ? "网页视频" : kind === "image" ? "网页图片" : "网页文件";

    const asset = await saveAsset({
      id: makeId(),
      kind,
      name: message.name || filenameFromUrl(message.url, fallbackName),
      mime,
      size: blob.size,
      blob,
      folderId: message.folderId || "",
      url: message.url,
      trashed: false,
      trashedAt: 0,
      sourceUrl: message.pageUrl || sender.tab?.url || "",
      createdAt: Date.now()
    });
    syncAssetToWebDav(asset.id).catch(() => {});

    chrome.runtime.sendMessage({ type: "ASSETS_CHANGED" }).catch(() => {});
    sendResponse({ ok: true });
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message || "保存失败" });
  });

  return true;
});
