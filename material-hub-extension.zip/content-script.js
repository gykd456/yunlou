﻿const MIN_TARGET_SIZE = 80;
const DRAG_ASSET_MIME = "application/material-hub-asset-id";
const SETTINGS_KEY = "materialHubSettings";
const FOLDERS_KEY = "materialHubFolders";
const FLOAT_ANIMATION_FRAME_COUNT = 48;
const FLOAT_ANIMATION_INTERVAL = 70;
const FLOAT_BALL_SIZE = 88;
const FLOAT_BALL_HALF = FLOAT_BALL_SIZE / 2;
const HOVER_SAVE_WIDTH = 136;
const HOVER_SAVE_HEIGHT = 40;
const HOVER_SAVE_GAP = 8;
let currentTarget = null;
let hideTimer = 0;
let selectedText = "";
let captureItems = [];
let floatDrag = null;
let suppressFloatClick = false;
let regionStart = null;
let sidePanelRequestedOpen = false;

function isExtensionContextAvailable() {
  try {
    return Boolean(globalThis.chrome?.runtime?.id);
  } catch {
    return false;
  }
}

function extensionUrl(path) {
  try {
    return isExtensionContextAvailable() ? chrome.runtime.getURL(path) : "";
  } catch {
    return "";
  }
}

async function sendRuntimeMessage(message) {
  if (!isExtensionContextAvailable()) {
    return { ok: false, error: "扩展已重新加载，请刷新当前网页" };
  }
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    return { ok: false, error: error.message || "扩展通信失败" };
  }
}

function storageLocalGet(keys, callback) {
  if (!isExtensionContextAvailable()) {
    callback({});
    return;
  }
  try {
    chrome.storage?.local?.get(keys, callback);
  } catch {
    callback({});
  }
}

function storageLocalSet(value) {
  if (!isExtensionContextAvailable()) return;
  try {
    chrome.storage?.local?.set(value);
  } catch {
    // The extension context can be invalidated after a reload while the page stays open.
  }
}

const button = document.createElement("div");
button.className = "mh-save-button";
button.innerHTML = `
  <button class="mh-save-main" type="button">保存素材</button>
  <button class="mh-save-folder" type="button" title="选择文件夹保存" aria-label="选择文件夹保存">
    <img alt="" src="${extensionUrl("fish-hook.svg")}">
  </button>
  <div class="mh-folder-menu" role="menu"></div>
`;
document.documentElement.append(button);
const saveMainButton = button.querySelector(".mh-save-main");
const saveFolderButton = button.querySelector(".mh-save-folder");
const saveFolderMenu = button.querySelector(".mh-folder-menu");

const selectionButton = document.createElement("div");
selectionButton.className = "mh-selection-button";
selectionButton.innerHTML =
  '<button class="mh-selection-main" type="button">保存文字</button>' +
  '<button class="mh-selection-folder" type="button" title="选择文件夹保存" aria-label="选择文件夹保存">' +
  '<img alt="" src="' + extensionUrl("fish-hook.svg") + '">' +
  '</button>' +
  '<div class="mh-folder-menu mh-selection-folder-menu" role="menu"></div>';
document.documentElement.append(selectionButton);
const selectionMainButton = selectionButton.querySelector(".mh-selection-main");
const selectionFolderButton = selectionButton.querySelector(".mh-selection-folder");
const selectionFolderMenu = selectionButton.querySelector(".mh-selection-folder-menu");

const floatDock = document.createElement("div");
floatDock.className = "mh-float-dock";

const floatClose = document.createElement("button");
floatClose.className = "mh-float-close";
floatClose.type = "button";
floatClose.title = "关闭悬浮窗";
floatClose.setAttribute("aria-label", "关闭悬浮窗");
floatClose.textContent = "×";

const floatRegion = document.createElement("button");
floatRegion.className = "mh-float-action mh-float-region";
floatRegion.type = "button";
floatRegion.title = "选择区域保存";
floatRegion.setAttribute("aria-label", "选择区域保存");
floatRegion.innerHTML = `<img alt="" src="${extensionUrl("fish-net.svg")}">`;

const floatBall = document.createElement("button");
floatBall.className = "mh-float-ball";
floatBall.type = "button";
floatBall.title = "抓取本页图片和视频";
floatBall.innerHTML = `<img alt="云篓悬浮窗" src="${extensionUrl("float-animation/frame-00000.png")}">`;

const floatOpenAll = document.createElement("button");
floatOpenAll.className = "mh-float-action mh-float-open-all";
floatOpenAll.type = "button";
floatOpenAll.title = "打开/关闭云篓面板";
floatOpenAll.setAttribute("aria-label", "打开云篓面板");
floatOpenAll.innerHTML = `<img alt="" src="${extensionUrl("all-fish-frame.svg")}">`;

floatDock.append(floatClose, floatRegion, floatBall, floatOpenAll);
document.documentElement.append(floatDock);

const floatBallImage = floatBall.querySelector("img");
if (floatBallImage && extensionUrl("float-animation/frame-00000.png")) {
  const floatFrameUrls = Array.from({ length: FLOAT_ANIMATION_FRAME_COUNT }, (_, index) =>
    extensionUrl(`float-animation/frame-${String(index).padStart(5, "0")}.png`)
  );
  const preloadFloatFrame = (index) => {
    const image = new Image();
    image.src = floatFrameUrls[index % FLOAT_ANIMATION_FRAME_COUNT];
  };
  preloadFloatFrame(1);
  let floatFrameIndex = 0;
  window.setInterval(() => {
    floatFrameIndex = (floatFrameIndex + 1) % FLOAT_ANIMATION_FRAME_COUNT;
    floatBallImage.src = floatFrameUrls[floatFrameIndex];
    preloadFloatFrame(floatFrameIndex + 1);
  }, FLOAT_ANIMATION_INTERVAL);
}

const capturePanel = document.createElement("section");
capturePanel.className = "mh-capture-panel";
capturePanel.innerHTML = `
  <div class="mh-capture-head">
    <div class="mh-capture-title">抓取本页素材</div>
    <button class="mh-capture-close" type="button" aria-label="关闭">×</button>
  </div>
  <div class="mh-capture-body">
    <div class="mh-capture-stats">点击悬浮球扫描页面</div>
    <button class="mh-save-visible" type="button">抓取可见图片</button>
    <button class="mh-select-region" type="button">选择区域保存</button>
    <div class="mh-capture-actions">
      <button class="mh-save-images" type="button">保存全部图片</button>
      <button class="mh-save-videos" type="button">保存全部视频</button>
    </div>
    <div class="mh-capture-list"></div>
  </div>
`;
document.documentElement.append(capturePanel);

const captureEls = {
  close: capturePanel.querySelector(".mh-capture-close"),
  stats: capturePanel.querySelector(".mh-capture-stats"),
  saveVisible: capturePanel.querySelector(".mh-save-visible"),
  selectRegion: capturePanel.querySelector(".mh-select-region"),
  saveImages: capturePanel.querySelector(".mh-save-images"),
  saveVideos: capturePanel.querySelector(".mh-save-videos"),
  list: capturePanel.querySelector(".mh-capture-list")
};

const regionMask = document.createElement("div");
regionMask.className = "mh-region-mask";
regionMask.innerHTML = `
  <div class="mh-region-tip">拖动选择要保存的页面区域，按 ESC 取消</div>
  <div class="mh-region-box"></div>
`;
document.documentElement.append(regionMask);
const regionBox = regionMask.querySelector(".mh-region-box");

function getMediaUrl(target) {
  if (target instanceof HTMLImageElement) {
    return target.currentSrc || target.src;
  }

  if (target instanceof HTMLVideoElement) {
    return target.currentSrc || target.src || target.querySelector("source")?.src || "";
  }

  return "";
}

function normalizeUrl(url) {
  try {
    return new URL(url, location.href).href;
  } catch {
    return "";
  }
}

function filenameFromUrl(url, fallback) {
  try {
    const parsed = new URL(url);
    return decodeURIComponent(parsed.pathname.split("/").filter(Boolean).pop() || "") || fallback;
  } catch {
    return fallback;
  }
}

function sourceUrlForElement(element) {
  const link = element instanceof Element ? element.closest("a[href]") : null;
  return normalizeUrl(link?.getAttribute("href") || location.href);
}

function isSavableUrl(url) {
  return Boolean(url) && !url.startsWith("blob:") && !url.startsWith("chrome-extension:");
}

function mediaKey(item) {
  return `${item.kind}:${item.url}`;
}

function rectsIntersect(a, b) {
  return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
}

function collectBackgroundImages() {
  const items = [];
  for (const element of document.querySelectorAll("body *")) {
    const style = window.getComputedStyle(element);
    const value = style.backgroundImage;
    if (!value || value === "none") continue;
    const matches = [...value.matchAll(/url\(["']?([^"')]+)["']?\)/g)];
    for (const match of matches) {
      const url = normalizeUrl(match[1]);
      const rect = element.getBoundingClientRect();
      if (isSavableUrl(url) && rect.width >= MIN_TARGET_SIZE && rect.height >= MIN_TARGET_SIZE) {
        items.push({
          kind: "image",
          url,
          name: filenameFromUrl(url, "背景图片"),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          rect: {
            left: rect.left,
            top: rect.top,
            right: rect.right,
            bottom: rect.bottom
          },
          visible: rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth
        });
      }
    }
  }
  return items;
}

function collectPageMedia() {
  const items = [];

  for (const img of document.images) {
    const url = normalizeUrl(img.currentSrc || img.src);
    const rect = img.getBoundingClientRect();
    if (isSavableUrl(url) && Math.max(rect.width, img.naturalWidth || 0) >= MIN_TARGET_SIZE && Math.max(rect.height, img.naturalHeight || 0) >= MIN_TARGET_SIZE) {
      items.push({
        kind: "image",
        url,
        name: img.alt || img.title || filenameFromUrl(url, "网页图片"),
        sourceUrl: sourceUrlForElement(img),
        width: Math.round(img.naturalWidth || rect.width),
        height: Math.round(img.naturalHeight || rect.height),
        rect: {
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom
        },
        visible: rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth
      });
    }
  }

  items.push(...collectBackgroundImages());

  for (const video of document.querySelectorAll("video")) {
    const url = normalizeUrl(video.currentSrc || video.src || video.querySelector("source")?.src || "");
    const rect = video.getBoundingClientRect();
    if (isSavableUrl(url)) {
      items.push({
        kind: "video",
        url,
        name: video.title || filenameFromUrl(url, "网页视频"),
        sourceUrl: sourceUrlForElement(video),
        width: Math.round(video.videoWidth || rect.width),
        height: Math.round(video.videoHeight || rect.height),
        rect: {
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom
        },
        visible: rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth
      });
    }
  }

  const seen = new Set();
  return items.filter((item) => {
    const key = mediaKey(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function renderCapturePanel() {
  const imageCount = captureItems.filter((item) => item.kind === "image").length;
  const videoCount = captureItems.filter((item) => item.kind === "video").length;
  const visibleCount = captureItems.filter((item) => item.kind === "image" && item.visible).length;
  captureEls.stats.textContent = `发现 ${imageCount} 张图片、${videoCount} 个视频，可见图片 ${visibleCount} 张`;
  captureEls.saveImages.disabled = imageCount === 0;
  captureEls.saveVideos.disabled = videoCount === 0;
  captureEls.saveVisible.disabled = visibleCount === 0;
  captureEls.list.replaceChildren();

  for (const item of captureItems.slice(0, 24)) {
    const row = document.createElement("div");
    row.className = "mh-capture-item";

    const thumb = document.createElement("div");
    thumb.className = "mh-capture-thumb";
    if (item.kind === "image") {
      const img = document.createElement("img");
      img.alt = "";
      img.src = item.url;
      thumb.append(img);
    } else {
      thumb.textContent = "VIDEO";
    }

    const name = document.createElement("div");
    name.className = "mh-capture-name";
    name.textContent = `${item.name || item.kind} · ${item.width || "?"}×${item.height || "?"}`;

    const save = document.createElement("button");
    save.className = "mh-capture-save-one";
    save.type = "button";
    save.textContent = "保存";
    save.addEventListener("click", async () => {
      save.disabled = true;
      save.textContent = "保存中";
      const ok = await saveCapturedItem(item);
      save.textContent = ok ? "已保存" : "失败";
    });

    row.append(thumb, name, save);
    captureEls.list.append(row);
  }
}

function positionCapturePanel() {
  const ballRect = floatDock.getBoundingClientRect();
  const width = Math.min(330, window.innerWidth - 28);
  const spaceRight = window.innerWidth - ballRect.right;
  const onLeft = ballRect.left < window.innerWidth / 2;
  capturePanel.style.width = `${width}px`;
  capturePanel.style.left = onLeft ? "14px" : "auto";
  capturePanel.style.right = onLeft ? "auto" : "18px";
  const bottom = Math.max(18, window.innerHeight - ballRect.top + 12);
  if (bottom + 360 < window.innerHeight) {
    capturePanel.style.bottom = `${bottom}px`;
    capturePanel.style.top = "auto";
  } else {
    capturePanel.style.top = "18px";
    capturePanel.style.bottom = "auto";
  }
  if (spaceRight < 0) capturePanel.style.right = "18px";
}

async function saveCapturedItem(item) {
  const response = await sendRuntimeMessage({
    type: "SAVE_REMOTE_ASSET",
    url: item.url,
    name: item.name,
    pageUrl: item.sourceUrl || location.href
  });
  return Boolean(response?.ok);
}

async function saveCapturedItems(items, button) {
  const originalText = button.textContent;
  button.disabled = true;
  let okCount = 0;

  for (const [index, item] of items.entries()) {
    button.textContent = `保存中 ${index + 1}/${items.length}`;
    if (await saveCapturedItem(item)) okCount += 1;
  }

  button.textContent = `已保存 ${okCount}/${items.length}`;
  window.setTimeout(() => {
    button.textContent = originalText;
    button.disabled = false;
  }, 1200);
}

function scanAndOpenCapturePanel() {
  captureItems = collectPageMedia();
  renderCapturePanel();
  positionCapturePanel();
  capturePanel.classList.add("is-open");
}

function applyFloatEnabled(enabled) {
  floatDock.classList.toggle("is-disabled", !enabled);
  if (!enabled) capturePanel.classList.remove("is-open");
}

function restoreFloatEnabled() {
  storageLocalGet([SETTINGS_KEY], (result) => {
    applyFloatEnabled(result[SETTINGS_KEY]?.floatEnabled !== false);
  });
}

function restoreFloatPosition() {
  storageLocalGet(["materialHubFloat"], (result) => {
    const saved = result.materialHubFloat;
    if (!saved) {
      floatDock.classList.add("is-right-hidden");
      return;
    }
    const y = Math.min(window.innerHeight - 72, Math.max(14, saved.y || window.innerHeight - 154));
    floatDock.style.top = `${y}px`;
    floatDock.style.bottom = "auto";
    floatDock.classList.toggle("is-left-hidden", saved.side === "left");
    floatDock.classList.toggle("is-right-hidden", saved.side !== "left");
  });
}

function snapFloatBall(clientX, clientY) {
  const side = clientX < window.innerWidth / 2 ? "left" : "right";
  const y = Math.min(window.innerHeight - FLOAT_BALL_SIZE - 14, Math.max(14, clientY - FLOAT_BALL_HALF));
  floatDock.style.top = `${y}px`;
  floatDock.style.bottom = "auto";
  floatDock.style.left = "";
  floatDock.style.right = "";
  floatDock.classList.toggle("is-left-hidden", side === "left");
  floatDock.classList.toggle("is-right-hidden", side === "right");
  storageLocalSet({ materialHubFloat: { side, y } });
  positionCapturePanel();
}

function startRegionSelect() {
  capturePanel.classList.remove("is-open");
  regionStart = null;
  regionBox.style.display = "none";
  regionMask.classList.add("is-active");
}

function regionRectFromPoints(a, b) {
  return {
    left: Math.min(a.x, b.x),
    top: Math.min(a.y, b.y),
    right: Math.max(a.x, b.x),
    bottom: Math.max(a.y, b.y),
    width: Math.abs(a.x - b.x),
    height: Math.abs(a.y - b.y)
  };
}

function drawRegionBox(rect) {
  regionBox.style.display = "block";
  regionBox.style.left = `${rect.left}px`;
  regionBox.style.top = `${rect.top}px`;
  regionBox.style.width = `${rect.width}px`;
  regionBox.style.height = `${rect.height}px`;
}

async function finishRegionSelect(rect) {
  regionMask.classList.remove("is-active");
  regionBox.style.display = "none";
  regionStart = null;

  if (rect.width < 12 || rect.height < 12) return;

  captureItems = collectPageMedia();
  const items = captureItems.filter((item) => item.rect && rectsIntersect(item.rect, rect));
  renderCapturePanel();
  positionCapturePanel();
  capturePanel.classList.add("is-open");
  captureEls.stats.textContent = items.length ? `区域内发现 ${items.length} 个素材，正在保存` : "区域内没有发现可保存素材";
  if (items.length) await saveCapturedItems(items, captureEls.selectRegion);
}

function isUsefulTarget(target) {
  if (!(target instanceof HTMLImageElement) && !(target instanceof HTMLVideoElement)) return false;
  const rect = target.getBoundingClientRect();
  return rect.width >= MIN_TARGET_SIZE && rect.height >= MIN_TARGET_SIZE && Boolean(getMediaUrl(target));
}

function placeButton(target) {
  const rect = target.getBoundingClientRect();
  const left = Math.min(
    window.innerWidth - HOVER_SAVE_WIDTH - HOVER_SAVE_GAP,
    Math.max(HOVER_SAVE_GAP, rect.right - HOVER_SAVE_WIDTH)
  );
  const topOutside = rect.top - HOVER_SAVE_HEIGHT - HOVER_SAVE_GAP;
  const topInside = rect.top + HOVER_SAVE_GAP;
  const top = topOutside >= HOVER_SAVE_GAP
    ? topOutside
    : Math.min(window.innerHeight - HOVER_SAVE_HEIGHT - HOVER_SAVE_GAP, Math.max(HOVER_SAVE_GAP, topInside));
  button.style.left = `${left}px`;
  button.style.top = `${top}px`;
  button.style.display = "inline-flex";
}

function setSaveButtonState(state, text) {
  button.classList.remove("is-saving", "is-done", "is-error");
  if (state) button.classList.add(state);
  saveMainButton.textContent = text;
}

function scheduleHide(force = false) {
  clearTimeout(hideTimer);
  if (button.classList.contains("is-menu-open") && !force) return;
  hideTimer = window.setTimeout(() => {
    button.style.display = "none";
    button.classList.remove("is-menu-open");
    currentTarget = null;
  }, 450);
}

function forceHideSaveButton() {
  clearTimeout(hideTimer);
  button.style.display = "none";
  button.classList.remove("is-menu-open");
  currentTarget = null;
}

async function readFoldersForMenu() {
  return new Promise((resolve) => {
    storageLocalGet([FOLDERS_KEY], (result) => {
      resolve(Array.isArray(result[FOLDERS_KEY]) ? result[FOLDERS_KEY] : []);
    });
  });
}

async function renderFolderMenu(targetMenu = saveFolderMenu) {
  const folders = await readFoldersForMenu();
  targetMenu.replaceChildren();
  const items = [
    { id: "", name: "未分类" },
    ...folders.map((folder) => ({ id: folder.id, name: folder.name || "未命名文件夹" }))
  ];
  for (const folder of items) {
    const item = document.createElement("button");
    item.type = "button";
    item.dataset.folderId = folder.id;
    item.textContent = folder.name;
    targetMenu.append(item);
  }
}

async function saveCurrentMedia(folderId = "") {
  if (!currentTarget) return;
  const url = getMediaUrl(currentTarget);
  if (!url || url.startsWith("data:") || url.startsWith("blob:")) {
    setSaveButtonState("is-error", "无法保存");
    return;
  }

  setSaveButtonState("is-saving", "保存中");

  const response = await sendRuntimeMessage({
    type: "SAVE_REMOTE_ASSET",
    url,
    mime: currentTarget.currentSrc ? "" : currentTarget.type || "",
    name: currentTarget.getAttribute("alt") || currentTarget.getAttribute("title") || "",
    pageUrl: sourceUrlForElement(currentTarget) || location.href,
    folderId
  });

  setSaveButtonState(response?.ok ? "is-done" : "is-error", response?.ok ? "已保存" : "保存失败");
  window.setTimeout(scheduleHide, 900);
}

document.addEventListener("mouseover", (event) => {
  const target = event.target;
  if (!isUsefulTarget(target)) return;
  currentTarget = target;
  clearTimeout(hideTimer);
  button.className = "mh-save-button";
  button.classList.toggle("is-video-target", target instanceof HTMLVideoElement);
  setSaveButtonState("", target instanceof HTMLVideoElement ? "保存视频" : "保存图片");
  placeButton(target);
}, true);

document.addEventListener("scroll", () => {
  if (currentTarget) placeButton(currentTarget);
}, true);

window.addEventListener("resize", () => {
  if (currentTarget) placeButton(currentTarget);
});

button.addEventListener("mouseenter", () => clearTimeout(hideTimer));
button.addEventListener("mouseleave", scheduleHide);
saveFolderMenu.addEventListener("mouseenter", () => clearTimeout(hideTimer));
saveFolderMenu.addEventListener("mouseleave", () => scheduleHide(true));

document.addEventListener("mouseout", (event) => {
  if (event.target !== currentTarget) return;
  const next = event.relatedTarget;
  if (next && button.contains(next)) return;
  scheduleHide();
}, true);

saveMainButton.addEventListener("click", () => saveCurrentMedia());

saveFolderButton.addEventListener("click", async (event) => {
  event.stopPropagation();
  clearTimeout(hideTimer);
  await renderFolderMenu();
  button.classList.toggle("is-menu-open");
});

saveFolderMenu.addEventListener("click", (event) => {
  const item = event.target.closest("button[data-folder-id]");
  if (!item) return;
  button.classList.remove("is-menu-open");
  saveCurrentMedia(item.dataset.folderId || "");
});

document.addEventListener("pointerdown", (event) => {
  if (!button.classList.contains("is-menu-open")) return;
  if (button.contains(event.target)) return;
  forceHideSaveButton();
}, true);

floatBall.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  floatDrag = {
    id: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    moved: false
  };
  floatDock.classList.add("is-dragging");
  floatBall.setPointerCapture(event.pointerId);
});

floatBall.addEventListener("pointermove", (event) => {
  if (!floatDrag || floatDrag.id !== event.pointerId) return;
  const dx = Math.abs(event.clientX - floatDrag.startX);
  const dy = Math.abs(event.clientY - floatDrag.startY);
  if (dx > 4 || dy > 4) floatDrag.moved = true;
  if (!floatDrag.moved) return;
  suppressFloatClick = true;
  floatDock.classList.remove("is-left-hidden", "is-right-hidden");
  floatDock.style.left = `${Math.min(window.innerWidth - FLOAT_BALL_SIZE, Math.max(0, event.clientX - FLOAT_BALL_HALF))}px`;
  floatDock.style.right = "auto";
  floatDock.style.top = `${Math.min(window.innerHeight - FLOAT_BALL_SIZE, Math.max(0, event.clientY - FLOAT_BALL_HALF))}px`;
  floatDock.style.bottom = "auto";
  positionCapturePanel();
});

floatBall.addEventListener("pointerup", (event) => {
  if (!floatDrag || floatDrag.id !== event.pointerId) return;
  floatDock.classList.remove("is-dragging");
  if (floatDrag.moved) snapFloatBall(event.clientX, event.clientY);
  floatDrag = null;
  window.setTimeout(() => {
    suppressFloatClick = false;
  }, 0);
});

floatBall.addEventListener("pointercancel", () => {
  floatDock.classList.remove("is-dragging");
  floatDrag = null;
  suppressFloatClick = false;
  restoreFloatPosition();
});

floatClose.addEventListener("click", (event) => {
  event.stopPropagation();
  capturePanel.classList.remove("is-open");
  floatDock.classList.add("is-closed");
});

floatRegion.addEventListener("click", (event) => {
  event.stopPropagation();
  startRegionSelect();
});

floatOpenAll.addEventListener("click", (event) => {
  event.stopPropagation();
  capturePanel.classList.remove("is-open");
  sidePanelRequestedOpen = !sidePanelRequestedOpen;
  sendRuntimeMessage({ type: sidePanelRequestedOpen ? "OPEN_SIDE_PANEL" : "CLOSE_SIDE_PANEL" }).catch(() => {});
});

floatBall.addEventListener("click", () => {
  if (suppressFloatClick) return;
  if (capturePanel.classList.contains("is-open")) {
    capturePanel.classList.remove("is-open");
    return;
  }
  scanAndOpenCapturePanel();
});

captureEls.close.addEventListener("click", () => capturePanel.classList.remove("is-open"));
document.addEventListener("pointerdown", (event) => {
  if (!capturePanel.classList.contains("is-open")) return;
  const target = event.target;
  if (capturePanel.contains(target) || floatDock.contains(target)) return;
  capturePanel.classList.remove("is-open");
}, true);
captureEls.saveVisible.addEventListener("click", () => {
  const items = captureItems.filter((item) => item.kind === "image" && item.visible);
  saveCapturedItems(items, captureEls.saveVisible);
});
captureEls.selectRegion.addEventListener("click", startRegionSelect);
captureEls.saveImages.addEventListener("click", () => {
  const items = captureItems.filter((item) => item.kind === "image");
  saveCapturedItems(items, captureEls.saveImages);
});

regionMask.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  regionStart = { x: event.clientX, y: event.clientY };
  drawRegionBox({ left: event.clientX, top: event.clientY, width: 0, height: 0 });
});

regionMask.addEventListener("pointermove", (event) => {
  if (!regionStart) return;
  drawRegionBox(regionRectFromPoints(regionStart, { x: event.clientX, y: event.clientY }));
});

regionMask.addEventListener("pointerup", (event) => {
  if (!regionStart) return;
  const rect = regionRectFromPoints(regionStart, { x: event.clientX, y: event.clientY });
  finishRegionSelect(rect);
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  regionMask.classList.remove("is-active");
  regionBox.style.display = "none";
  regionStart = null;
});

window.addEventListener("resize", () => {
  if (!floatDrag) restoreFloatPosition();
  positionCapturePanel();
});
try {
  if (isExtensionContextAvailable()) {
    chrome.storage?.onChanged?.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes[SETTINGS_KEY]) return;
      applyFloatEnabled(changes[SETTINGS_KEY].newValue?.floatEnabled !== false);
    });
  }
} catch {
  // Ignore stale content scripts left behind after extension reloads.
}
captureEls.saveVideos.addEventListener("click", () => {
  const items = captureItems.filter((item) => item.kind === "video");
  saveCapturedItems(items, captureEls.saveVideos);
});

function isTextInput(element) {
  return element instanceof HTMLInputElement && !element.disabled && !element.readOnly && ["email", "password", "search", "tel", "text", "url"].includes(element.type);
}

function isTextArea(element) {
  return element instanceof HTMLTextAreaElement && !element.disabled && !element.readOnly;
}

function isEditable(element) {
  return isTextInput(element) || isTextArea(element) || element instanceof HTMLElement && element.isContentEditable;
}

function findEditable(event) {
  const candidates = [event.target, document.elementFromPoint(event.clientX, event.clientY)];
  for (const candidate of candidates) {
    let node = candidate instanceof Element ? candidate : null;
    while (node && node !== document.documentElement) {
      if (isEditable(node)) return node;
      node = node.parentElement;
    }
  }
  return null;
}

function dispatchTextInput(element, text) {
  element.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, data: text, inputType: "insertText" }));
  element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
}

function insertIntoField(element, text) {
  const start = typeof element.selectionStart === "number" ? element.selectionStart : element.value.length;
  const end = typeof element.selectionEnd === "number" ? element.selectionEnd : element.value.length;
  const next = `${element.value.slice(0, start)}${text}${element.value.slice(end)}`;
  const proto = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  element.focus({ preventScroll: true });
  setter ? setter.call(element, next) : element.value = next;
  element.setSelectionRange(start + text.length, start + text.length);
  dispatchTextInput(element, text);
}

function rangeFromPoint(event) {
  if (document.caretRangeFromPoint) return document.caretRangeFromPoint(event.clientX, event.clientY);
  const position = document.caretPositionFromPoint?.(event.clientX, event.clientY);
  if (!position) return null;
  const range = document.createRange();
  range.setStart(position.offsetNode, position.offset);
  range.collapse(true);
  return range;
}

function insertIntoContentEditable(element, text, event) {
  element.focus({ preventScroll: true });
  const selection = window.getSelection();
  let range = rangeFromPoint(event);
  if (!range || !element.contains(range.startContainer)) {
    range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
  }
  selection?.removeAllRanges();
  selection?.addRange(range);
  if (!document.execCommand("insertText", false, text)) {
    range.deleteContents();
    const node = document.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    selection?.removeAllRanges();
    selection?.addRange(range);
  }
  dispatchTextInput(element, text);
}

function insertTextAtDrop(event, text) {
  const target = findEditable(event);
  if (!target) return false;
  event.preventDefault();
  event.stopImmediatePropagation();
  if (isTextInput(target) || isTextArea(target)) {
    insertIntoField(target, text);
  } else {
    insertIntoContentEditable(target, text, event);
  }
  return true;
}

function insertMediaAtDrop(event, asset) {
  const target = findEditable(event);
  if (!(target instanceof HTMLElement) || isTextInput(target) || isTextArea(target)) return false;
  event.preventDefault();
  event.stopImmediatePropagation();
  target.focus({ preventScroll: true });
  const selection = window.getSelection();
  let range = rangeFromPoint(event);
  if (!range || !target.contains(range.startContainer)) {
    range = document.createRange();
    range.selectNodeContents(target);
    range.collapse(false);
  }
  const element = asset.kind === "video" ? document.createElement("video") : document.createElement("img");
  element.src = asset.dataUrl;
  element.title = asset.name || "";
  element.setAttribute("data-yunlou-asset", asset.id || "");
  if (element instanceof HTMLImageElement) {
    element.alt = asset.name || "";
    element.style.maxWidth = "100%";
  } else {
    element.controls = true;
    element.style.maxWidth = "100%";
  }
  range.deleteContents();
  range.insertNode(element);
  range.setStartAfter(element);
  range.collapse(true);
  selection?.removeAllRanges();
  selection?.addRange(range);
  target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertHTML" }));
  return true;
}

function dataUrlToFile(dataUrl, name, mime) {
  const [header, body = ""] = dataUrl.split(",");
  const contentType = mime || header.match(/^data:([^;]+)/)?.[1] || "application/octet-stream";
  const binary = atob(body);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new File([bytes], name || "material", { type: contentType });
}

function findFileInput(event) {
  const target = event.target instanceof Element ? event.target : document.elementFromPoint(event.clientX, event.clientY);
  if (target instanceof HTMLInputElement && target.type === "file") return target;
  return target?.closest?.("label")?.querySelector?.("input[type=file]") ||
    target?.querySelector?.("input[type=file]") ||
    target?.parentElement?.querySelector?.("input[type=file]") ||
    null;
}

function assignFilesToInput(input, files) {
  Object.defineProperty(input, "files", { value: files, configurable: true });
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

function dispatchSyntheticFileDrop(event, file) {
  const target = event.target instanceof Element ? event.target : document.elementFromPoint(event.clientX, event.clientY);
  if (!target) return false;
  const transfer = new DataTransfer();
  transfer.items.add(file);
  const dropEvent = new DragEvent("drop", {
    bubbles: true,
    cancelable: true,
    clientX: event.clientX,
    clientY: event.clientY,
    dataTransfer: transfer
  });
  target.dispatchEvent(dropEvent);
  return dropEvent.defaultPrevented;
}

async function dropHubAsset(event, id) {
  event.preventDefault();
  event.stopImmediatePropagation();
  const response = await sendRuntimeMessage({ type: "GET_ASSET_FOR_DROP", id });
  if (!response?.ok || !response.asset) return false;
  const asset = response.asset;
  if (asset.kind === "text") return insertTextAtDrop(event, asset.text || "");
  if (insertMediaAtDrop(event, asset)) return true;
  const file = dataUrlToFile(asset.dataUrl, asset.name, asset.mime);
  const transfer = new DataTransfer();
  transfer.items.add(file);
  const input = findFileInput(event);
  if (input instanceof HTMLInputElement) {
    assignFilesToInput(input, transfer.files);
    return true;
  }
  dispatchSyntheticFileDrop(event, file);
  return true;
}

function dropFilesIntoInput(event) {
  const files = event.dataTransfer?.files;
  if (!files?.length) return false;
  const input = findFileInput(event);
  if (!(input instanceof HTMLInputElement)) return false;
  event.preventDefault();
  event.stopImmediatePropagation();
  assignFilesToInput(input, files);
  return true;
}

document.addEventListener("dragover", (event) => {
  if (event.dataTransfer?.types.includes(DRAG_ASSET_MIME) || event.dataTransfer?.types.includes("application/material-hub-text") || event.dataTransfer?.files?.length) {
    event.preventDefault();
    if (event.dataTransfer?.types.includes(DRAG_ASSET_MIME) || event.dataTransfer?.types.includes("application/material-hub-text")) {
      event.stopImmediatePropagation();
    }
    event.dataTransfer.dropEffect = "copy";
  }
}, true);

document.addEventListener("drop", (event) => {
  const hubAssetId = event.dataTransfer?.getData(DRAG_ASSET_MIME);
  if (hubAssetId) {
    dropHubAsset(event, hubAssetId);
    return;
  }
  const hubText = event.dataTransfer?.getData("application/material-hub-text");
  if (hubText && insertTextAtDrop(event, hubText)) return;
  if (dropFilesIntoInput(event)) return;
}, true);

function hideSelectionButton() {
  selectionButton.style.display = "none";
  selectionButton.className = "mh-selection-button";
  selectionMainButton.textContent = "保存文字";
  selectedText = "";
}

async function saveSelectedText(folderId = "") {
  if (!selectedText) return;
  selectionButton.className = "mh-selection-button is-saving";
  selectionMainButton.textContent = "保存中";
  const response = await sendRuntimeMessage({
    type: "SAVE_TEXT_ASSET",
    text: selectedText,
    pageUrl: location.href,
    folderId
  });
  selectionButton.className = `mh-selection-button ${response?.ok ? "is-done" : "is-error"}`;
  selectionMainButton.textContent = response?.ok ? "已保存" : "保存失败";
  window.setTimeout(hideSelectionButton, 900);
}

selectionButton.addEventListener("mousedown", (event) => {
  event.preventDefault();
});

selectionMainButton.addEventListener("click", () => saveSelectedText());

selectionFolderButton.addEventListener("click", async (event) => {
  event.stopPropagation();
  await renderFolderMenu(selectionFolderMenu);
  selectionButton.classList.toggle("is-menu-open");
});

selectionFolderMenu.addEventListener("click", (event) => {
  const item = event.target.closest("button[data-folder-id]");
  if (!item) return;
  selectionButton.classList.remove("is-menu-open");
  saveSelectedText(item.dataset.folderId || "");
});

document.addEventListener("mouseup", (event) => {
  if (selectionButton.contains(event.target)) return;
  window.setTimeout(() => {
    const selection = window.getSelection();
    const text = selection?.toString().trim() || "";
    if (text.length < 2) {
      hideSelectionButton();
      return;
    }
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    selectedText = text;
    selectionButton.className = "mh-selection-button";
    selectionMainButton.textContent = "保存文字";
    selectionButton.style.left = `${Math.min(window.innerWidth - 152, Math.max(8, rect.right - 142))}px`;
    selectionButton.style.top = `${Math.max(8, rect.top - 40)}px`;
    selectionButton.style.display = "inline-flex";
  }, 0);
}, true);

document.addEventListener("keydown", hideSelectionButton);

restoreFloatPosition();
restoreFloatEnabled();
